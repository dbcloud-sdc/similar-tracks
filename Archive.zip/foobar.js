// const path = require('path');

// console.log(path.resolve());

// console.log(path.join(__dirname, '/dist'));
