import React from 'react';
import style from 'styled-components';
// const { styled } = window;


const Grey = style.div`
color: #999;
`;

export default Grey;
